Text Game Maker JS

GitHub: https://github.com/a-mean-blogger/text-game-maker-js

Documentations & Tutorials:
- English: http://www.a-mean-blog.com/en/blog/Text-Game-Maker-JS
- 한글: http://www.a-mean-blog.com/ko/blog/Text-Game-Maker-JS

license: MIT

Copyright 2017 a.mean.blogger@gmail.com
