// copy and paste this codes to main.js in starter program and open index.html on a web browser

var TMS = new TM.ScreenManager();

TMS.insertText("Hello World\n");
