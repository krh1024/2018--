Text Game Maker JS
=====
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

[Read this in English](README.md)

## 요약

Text Game Maker JS는 웹브라우저용 텍스트 게임 제작 라이브러리입니다. 콘솔(도스창)모양의 canvas를 생성하여 문자를 출력하고 사용자의 입력을 받을 수 있습니다.

## 데모

테트리스: [http://www.a-mean-blog.com/ko/blog/Text-Game-Maker-JS/Games/테트리스](http://www.a-mean-blog.com/ko/blog/Text-Game-Maker-JS/Games/테트리스)

## 문서 및 튜토리얼

한글: [http://www.a-mean-blog.com/ko/blog/Text-Game-Maker-JS](http://www.a-mean-blog.com/ko/blog/Text-Game-Maker-JS)

English: [http://www.a-mean-blog.com/en/blog/Text-Game-Maker-JS](http://www.a-mean-blog.com/en/blog/Text-Game-Maker-JS)

## 온라인 샌드박스

[https://a-mean-blogger.github.io/text-game-maker-js/sandbox](https://a-mean-blogger.github.io/text-game-maker-js/sandbox)

## Copyright

Text Game Maker JS Copyright (c) 2017 a.mean.blogger@gmail.com
